/* ============================================
   GOLD LAYER - Analytics / Fact & Dimension Tables
   ============================================ */

/* ==========================
   1️⃣ Create Customers Dimension
   ========================== */
DROP TABLE IF EXISTS gold.dim_customers;
CREATE TABLE gold.dim_customers AS
SELECT
    customer_id,
    name,
    country,
    signup_date
FROM silver.customers;

/* ==========================
   2️⃣ Create Products Dimension
   ========================== */
DROP TABLE IF EXISTS gold.dim_products;
CREATE TABLE gold.dim_products AS
SELECT
    product_id,
    product_name,
    category,
    price
FROM silver.products;

/* ==========================
   3️⃣ Create Date Dimension
   Generate calendar table from order dates
   ========================== */
DROP TABLE IF EXISTS gold.dim_date;
CREATE TABLE gold.dim_date AS
WITH dates AS (
    SELECT MIN(order_date) AS start_date, MAX(order_date) AS end_date FROM silver.orders
)
SELECT 
    generate_series(start_date, end_date, '1 day'::interval)::DATE AS calendar_date
FROM dates;

-- Add year, month, day columns
ALTER TABLE gold.dim_date
ADD COLUMN year INT,
ADD COLUMN month INT,
ADD COLUMN day INT;

UPDATE gold.dim_date
SET year = EXTRACT(YEAR FROM calendar_date),
    month = EXTRACT(MONTH FROM calendar_date),
    day = EXTRACT(DAY FROM calendar_date);

/* ==========================
   4️⃣ Create Orders Fact Table
   ========================== */
DROP TABLE IF EXISTS gold.fact_orders;
CREATE TABLE gold.fact_orders AS
SELECT
    o.order_id,
    o.customer_id,
    o.order_date,
    o.total_amount
FROM silver.orders o;

/* ==========================
   5️⃣ Create Order Items Fact Table
   ========================== */
DROP TABLE IF EXISTS gold.fact_order_items;
CREATE TABLE gold.fact_order_items AS
SELECT
    oi.order_item_id,
    oi.order_id,
    oi.product_id,
    oi.quantity,
    oi.price,
    (oi.quantity * oi.price)::NUMERIC(10,2) AS total_price
FROM silver.order_items oi;

/* ==========================
   6️⃣ Create Shipments Fact Table
   Calculate delivery days
   ========================== */
DROP TABLE IF EXISTS gold.fact_shipments;
CREATE TABLE gold.fact_shipments AS
SELECT
    shipment_id,
    order_id,
    shipped_date,
    delivery_date,
    (delivery_date - shipped_date) AS delivery_days,
    status
FROM silver.shipments
WHERE delivery_date IS NOT NULL;

/* ==========================
   7️⃣ Sample Analytics Queries
   ========================== */

/* Monthly Sales Trend */
SELECT 
    TO_CHAR(DATE_TRUNC('month', o.order_date), 'YYYY-MM') AS month,
    SUM(o.total_amount) AS monthly_sales
FROM gold.fact_orders o
GROUP BY month
ORDER BY month;


/* Top 10 Products by Revenue */
SELECT 
    p.product_name,
    SUM(oi.total_price) AS revenue
FROM gold.fact_order_items oi
JOIN gold.dim_products p ON oi.product_id = p.product_id
GROUP BY p.product_name
ORDER BY revenue DESC
LIMIT 10;

/* Customer Lifetime Value (CLV) */
SELECT 
    c.name,
    SUM(o.total_amount) AS lifetime_value
FROM gold.fact_orders o
JOIN gold.dim_customers c ON o.customer_id = c.customer_id
GROUP BY c.name
ORDER BY lifetime_value DESC;

/* Delivery Performance Metrics */
SELECT 
    AVG(delivery_days) AS avg_delivery_time,
    SUM(CASE WHEN delivery_days > 7 THEN 1 ELSE 0 END)::FLOAT / COUNT(*) * 100 AS pct_delayed
FROM gold.fact_shipments;
