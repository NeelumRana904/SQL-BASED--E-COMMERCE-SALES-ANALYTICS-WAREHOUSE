/* ============================================
   SILVER LAYER - Cleaned & Transformed Tables
   ============================================ */

/* ==========================
   1️⃣ Create Silver Schema
   ========================== */
CREATE SCHEMA IF NOT EXISTS silver;

/* ==========================
   2️⃣ Customers Table (Silver)
   Clean names, handle missing countries
   ========================== */
DROP TABLE IF EXISTS silver.customers;
CREATE TABLE silver.customers AS
SELECT
    customer_id,
    INITCAP(TRIM(name)) AS name,
    signup_date,
    COALESCE(NULLIF(country, ''), 'Unknown') AS country
FROM bronze.customers;

-- Check first 10 rows
SELECT * FROM silver.customers LIMIT 10;

/* ==========================
   3️⃣ Products Table (Silver)
   Clean product names, ensure valid prices
   ========================== */
DROP TABLE IF EXISTS silver.products;
CREATE TABLE silver.products AS
SELECT DISTINCT
    product_id,
    INITCAP(TRIM(product_name)) AS product_name,
    category,
    (price::TEXT) ~ '^[0-9]+(\.[0-9]{1,2})?$' AS is_valid_price,  -- optional validity check
    price::NUMERIC(10,2) AS price
FROM bronze.products
WHERE (price::TEXT) ~ '^[0-9]+(\.[0-9]{1,2})?$';

-- Check first 10 rows
SELECT * FROM silver.products LIMIT 10;

/* ==========================
   4️⃣ Orders Table (Silver)
   Ensure numeric total_amount, valid order_id
   ========================== */
DROP TABLE IF EXISTS silver.orders;
CREATE TABLE silver.orders AS
SELECT
    order_id,
    customer_id,
    order_date::DATE AS order_date,
    total_amount::NUMERIC(10,2) AS total_amount
FROM bronze.orders
WHERE order_id IS NOT NULL;

-- Check first 10 rows
SELECT * FROM silver.orders LIMIT 10;

/* ==========================
   5️⃣ Order Items Table (Silver)
   Ensure quantity & price are positive
   ========================== */
DROP TABLE IF EXISTS silver.order_items;
CREATE TABLE silver.order_items AS
SELECT
    order_item_id,
    order_id,
    product_id,
    quantity::INT,
    price::NUMERIC(10,2)
FROM bronze.order_items
WHERE quantity > 0 AND price > 0;

-- Check first 10 rows
SELECT * FROM silver.order_items LIMIT 10;

/* ==========================
   6️⃣ Shipments Table (Silver)
   Clean status, convert dates to DATE type
   ========================== */
DROP TABLE IF EXISTS silver.shipments;
CREATE TABLE silver.shipments AS
SELECT
    shipment_id,
    order_id,
    shipped_date::DATE AS shipped_date,
    delivery_date::DATE AS delivery_date,
    INITCAP(TRIM(status)) AS status
FROM bronze.shipments
WHERE shipment_id IS NOT NULL;

-- Check first 10 rows
SELECT * FROM silver.shipments LIMIT 10;
