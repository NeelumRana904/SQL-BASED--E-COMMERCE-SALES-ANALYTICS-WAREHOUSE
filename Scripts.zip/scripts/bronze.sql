-- ============================================
-- BRONZE LAYER - Raw Data Tables
-- ============================================

-- 1️⃣ Create Bronze Schema
CREATE SCHEMA IF NOT EXISTS bronze;

-- ============================================
-- 2️⃣ Create Customers Table
-- ============================================
DROP TABLE IF EXISTS bronze.customers;
CREATE TABLE bronze.customers (
    customer_id INT PRIMARY KEY,
    name VARCHAR(100),
    signup_date DATE,
    country VARCHAR(50)
);

-- ============================================
-- 3️⃣ Create Products Table
-- ============================================
DROP TABLE IF EXISTS bronze.products;
CREATE TABLE bronze.products (
    product_id INT PRIMARY KEY,
    product_name VARCHAR(100),
    category VARCHAR(50),
    price NUMERIC(10,2)
);

-- ============================================
-- 4️⃣ Create Orders Table
-- ============================================
DROP TABLE IF EXISTS bronze.orders;
CREATE TABLE bronze.orders (
    order_id INT PRIMARY KEY,
    customer_id INT,
    order_date DATE,
    total_amount NUMERIC(10,2)
);

-- ============================================
-- 5️⃣ Create Order Items Table
-- ============================================
DROP TABLE IF EXISTS bronze.order_items;
CREATE TABLE bronze.order_items (
    order_item_id INT PRIMARY KEY,
    order_id INT,
    product_id INT,
    quantity INT,
    price NUMERIC(10,2)
);

-- ============================================
-- 6️⃣ Create Shipments Table
-- ============================================
DROP TABLE IF EXISTS bronze.shipments;
CREATE TABLE bronze.shipments (
    shipment_id INT PRIMARY KEY,
    order_id INT,
    shipped_date DATE,
    delivery_date DATE,
    status VARCHAR(50)
);

-- ============================================
-- NOTE:
-- After running this script, import your CSV files into these tables
-- using pgAdmin's Import/Export tool.
-- Make sure the CSV header columns match the table column names exactly.
-- ============================================
